<?php
/*
Plugin Name: Estimación rápida
Plugin URI: https://webcafeina.com
Description: Estimador rápido de precio para aislamiento
Version: 0.1.156
Author: Webcafeina
Author URI: https://webcafeina.com
License: GPL2
*/

// INCLUIMOS DASHICONS
add_action( 'wp_enqueue_scripts', 'dashicons_front_end_estimador' );
function dashicons_front_end_estimador() {
    wp_enqueue_style( 'dashicons' );
}

// PÁGINA DE CONFIGURACIÓN DEL PLUGIN
function estimador_register_options_page() {
    add_menu_page(
      'Configuración del Estimador rápido', // Título de la página
      'Estimador rápido', // Título del menú
      'manage_options', // Capacidad requerida
      'estimador', // Identificador de menú único
      'estimador_options_page', // Función que muestra el contenido de la página
      'dashicons-money-alt', // Icono del menú
      11 // Posición en el menú
    );
}
add_action('admin_menu', 'estimador_register_options_page');

function estimador_options_page() {
    ?>
    <div class="wrap">
      <h1>Configuración del Estimador rápido</h1>
      <h2>Panel de administración del plugin estimador</h2>
      <h4 style="font-style: italic">Creado con &hearts; por Webcafeina para Eccoaisla</h4>
      <h3 style="font-weight: bold">PRECAUCIÓN: modificar estos datos supone la modificación de la lógica del plugin. Proceda con cuidado.</h3>
      <form action="options.php" method="post">
        <?php
            settings_fields('estimador_options_group');
            do_settings_sections('estimador');
            submit_button();
        ?>
      </form>
    </div>
    <?php
}

function estimador_register_settings() {
    register_setting(
      'estimador_options_group', // Grupo de opciones
      'estimador_options' // Nombre de la opción
    );

    add_settings_section(
        'estimador_general_section', // ID de la sección
        'Opciones de configuración', // Título de la sección
        null, // Función de devolución de llamada de la sección (opcional)
        'estimador' // ID de la página
    );
  
    add_settings_field(
        'estimador_webhook_url',
        'URL del webhook de Zapier',
        'estimador_webhook_url_callback',
        'estimador',
        'estimador_general_section'
    );

    add_settings_field(
        'estimador_correo_admin',
        'Correo al que enviar la notificación de los nuevos contactos',
        'estimador_correo_admin_callback',
        'estimador',
        'estimador_general_section'
    );

    add_settings_section(
      'estimador_paredes_section', // ID de la sección
      'Precios para paredes', // Título de la sección
      null, // Función de devolución de llamada de la sección (opcional)
      'estimador' // ID de la página
    );

    add_settings_field(
        'estimador_precio_paredes_menos50',
        'Precio para paredes con menos de 50 m²',
        'estimador_precio_paredes_menos50_callback',
        'estimador',
        'estimador_paredes_section'
    );

    add_settings_field(
        'estimador_precio_paredes_entre50_75',
        'Precio para paredes de entre 50 m² y 75 m²',
        'estimador_precio_paredes_entre50_75_callback',
        'estimador',
        'estimador_paredes_section'
    );

    add_settings_field(
        'estimador_precio_paredes_entre75_100',
        'Precio para paredes de entre 75 m² y 100 m²',
        'estimador_precio_paredes_entre75_100_callback',
        'estimador',
        'estimador_paredes_section'
    );

    add_settings_field(
        'estimador_precio_paredes_entre100_125',
        'Precio para paredes de entre 100 m² y 125 m²',
        'estimador_precio_paredes_entre100_125_callback',
        'estimador',
        'estimador_paredes_section'
    );

    add_settings_field(
        'estimador_precio_paredes_entre125_175',
        'Precio para paredes de entre 125 m² y 175 m²',
        'estimador_precio_paredes_entre125_175_callback',
        'estimador',
        'estimador_paredes_section'
    );

    add_settings_field(
        'estimador_precio_paredes_mas175',
        'Precio para paredes con más de 175 m²',
        'estimador_precio_paredes_mas175_callback',
        'estimador',
        'estimador_paredes_section'
    );

    add_settings_section(
        'estimador_cubierta_section', // ID de la sección
        'Precios para cubierta', // Título de la sección
        null, // Función de devolución de llamada de la sección (opcional)
        'estimador' // ID de la página
    );

    add_settings_field(
        'estimador_precio_cubierta_entre50_60',
        'Precio para cubierta de entre 50 m² y 60 m²',
        'estimador_precio_cubierta_entre50_60_callback',
        'estimador',
        'estimador_cubierta_section'
    );

    add_settings_field(
        'estimador_precio_cubierta_entre60_70',
        'Precio para cubierta de entre 60 m² y 70 m²',
        'estimador_precio_cubierta_entre60_70_callback',
        'estimador',
        'estimador_cubierta_section'
    );

    add_settings_field(
        'estimador_precio_cubierta_entre70_80',
        'Precio para cubierta de entre 70 m² y 80 m²',
        'estimador_precio_cubierta_entre70_80_callback',
        'estimador',
        'estimador_cubierta_section'
    );

    add_settings_field(
        'estimador_precio_cubierta_entre80_90',
        'Precio para cubierta de entre 80 m² y 90 m²',
        'estimador_precio_cubierta_entre80_90_callback',
        'estimador',
        'estimador_cubierta_section'
    );

    add_settings_field(
        'estimador_precio_cubierta_entre90_100',
        'Precio para cubierta de entre 90 m² y 100 m²',
        'estimador_precio_cubierta_entre90_100_callback',
        'estimador',
        'estimador_cubierta_section'
    );

    add_settings_field(
        'estimador_precio_cubierta_mas100',
        'Precio para cubierta con más de 100 m²',
        'estimador_precio_cubierta_mas100_callback',
        'estimador',
        'estimador_cubierta_section'
    );

    add_settings_section(
        'apertura_financiacion_section', // ID de la sección
        'Comisiones de apertura para financiación', // Título de la sección
        null, // Función de devolución de llamada de la sección (opcional)
        'estimador' // ID de la página
    );

    add_settings_field(
        'estimador_apertura_financiacion_3',
        'Comisión de apertura para 3 meses (%)',
        'estimador_apertura_financiacion_3_callback',
        'estimador',
        'apertura_financiacion_section'
    );

    add_settings_field(
        'estimador_apertura_financiacion_6',
        'Comisión de apertura para 6 meses (%)',
        'estimador_apertura_financiacion_6_callback',
        'estimador',
        'apertura_financiacion_section'
    );

    add_settings_field(
        'estimador_apertura_financiacion_10',
        'Comisión de apertura para 10 meses (%)',
        'estimador_apertura_financiacion_10_callback',
        'estimador',
        'apertura_financiacion_section'
    );

    add_settings_field(
        'estimador_apertura_financiacion_12',
        'Comisión de apertura para 12 meses (%)',
        'estimador_apertura_financiacion_12_callback',
        'estimador',
        'apertura_financiacion_section'
    );

    add_settings_field(
        'estimador_apertura_financiacion_18',
        'Comisión de apertura para 18 meses (%)',
        'estimador_apertura_financiacion_18_callback',
        'estimador',
        'apertura_financiacion_section'
    );

    add_settings_field(
        'estimador_apertura_financiacion_24',
        'Comisión de apertura para 24 meses (%)',
        'estimador_apertura_financiacion_24_callback',
        'estimador',
        'apertura_financiacion_section'
    );

    add_settings_field(
        'estimador_apertura_financiacion_36',
        'Comisión de apertura para 36 meses (%)',
        'estimador_apertura_financiacion_36_callback',
        'estimador',
        'apertura_financiacion_section'
    );


}
add_action('admin_init', 'estimador_register_settings');

function estimador_webhook_url_callback() {
    $options = get_option('estimador_options');
    echo '<input type="text" id="estimador_webhook_url" name="estimador_options[estimador_webhook_url]" value="' . esc_attr($options['estimador_webhook_url']) . '">';
}

function estimador_correo_admin_callback() {
    $options = get_option('estimador_options');
    echo '<input type="text" id="estimador_correo_admin" name="estimador_options[estimador_correo_admin]" value="' . esc_attr($options['estimador_correo_admin']) . '">';
}

function estimador_precio_paredes_menos50_callback() {
    $options = get_option('estimador_options');
    echo '<input type="number" step="any" id="estimador_precio_paredes_menos50" name="estimador_options[estimador_precio_paredes_menos50]" value="' . esc_attr($options['estimador_precio_paredes_menos50']) . '">';
}

function estimador_precio_paredes_entre50_75_callback() {
    $options = get_option('estimador_options');
    echo '<input type="number" step="any" id="estimador_precio_paredes_entre50_75" name="estimador_options[estimador_precio_paredes_entre50_75]" value="' . esc_attr($options['estimador_precio_paredes_entre50_75']) . '">';
}

function estimador_precio_paredes_entre75_100_callback() {
    $options = get_option('estimador_options');
    echo '<input type="number" step="any" id="estimador_precio_paredes_entre75_100" name="estimador_options[estimador_precio_paredes_entre75_100]" value="' . esc_attr($options['estimador_precio_paredes_entre75_100']) . '">';
}

function estimador_precio_paredes_entre100_125_callback() {
    $options = get_option('estimador_options');
    echo '<input type="number" step="any" id="estimador_precio_paredes_entre100_125" name="estimador_options[estimador_precio_paredes_entre100_125]" value="' . esc_attr($options['estimador_precio_paredes_entre100_125']) . '">';
}

function estimador_precio_paredes_entre125_175_callback() {
    $options = get_option('estimador_options');
    echo '<input type="number" step="any" id="estimador_precio_paredes_entre125_175" name="estimador_options[estimador_precio_paredes_entre125_175]" value="' . esc_attr($options['estimador_precio_paredes_entre125_175']) . '">';
}

function estimador_precio_paredes_mas175_callback() {
    $options = get_option('estimador_options');
    echo '<input type="number" step="any" id="estimador_precio_paredes_mas175" name="estimador_options[estimador_precio_paredes_mas175]" value="' . esc_attr($options['estimador_precio_paredes_mas175']) . '">';
}

function estimador_precio_cubierta_entre50_60_callback() {
    $options = get_option('estimador_options');
    echo '<input type="number" step="any" id="estimador_precio_cubierta_entre50_60" name="estimador_options[estimador_precio_cubierta_entre50_60]" value="' . esc_attr($options['estimador_precio_cubierta_entre50_60']) . '">';
}

function estimador_precio_cubierta_entre60_70_callback() {
    $options = get_option('estimador_options');
    echo '<input type="number" step="any" id="estimador_precio_cubierta_entre60_70" name="estimador_options[estimador_precio_cubierta_entre60_70]" value="' . esc_attr($options['estimador_precio_cubierta_entre60_70']) . '">';
}

function estimador_precio_cubierta_entre70_80_callback() {
    $options = get_option('estimador_options');
    echo '<input type="number" step="any" id="estimador_precio_cubierta_entre70_80" name="estimador_options[estimador_precio_cubierta_entre70_80]" value="' . esc_attr($options['estimador_precio_cubierta_entre70_80']) . '">';
}

function estimador_precio_cubierta_entre80_90_callback() {
    $options = get_option('estimador_options');
    echo '<input type="number" step="any" id="estimador_precio_cubierta_entre80_90" name="estimador_options[estimador_precio_cubierta_entre80_90]" value="' . esc_attr($options['estimador_precio_cubierta_entre80_90']) . '">';
}

function estimador_precio_cubierta_entre90_100_callback() {
    $options = get_option('estimador_options');
    echo '<input type="number" step="any" id="estimador_precio_cubierta_entre90_100" name="estimador_options[estimador_precio_cubierta_entre90_100]" value="' . esc_attr($options['estimador_precio_cubierta_entre90_100']) . '">';
}

function estimador_precio_cubierta_mas100_callback() {
    $options = get_option('estimador_options');
    echo '<input type="number" step="any" id="estimador_precio_cubierta_mas100" name="estimador_options[estimador_precio_cubierta_mas100]" value="' . esc_attr($options['estimador_precio_cubierta_mas100']) . '">';
}

function estimador_apertura_financiacion_3_callback() {
    $options = get_option('estimador_options');
    echo '<input type="number" step="any" id="estimador_apertura_financiacion_3" name="estimador_options[estimador_apertura_financiacion_3]" value="' . esc_attr($options['estimador_apertura_financiacion_3']) . '">';
}

function estimador_apertura_financiacion_6_callback() {
    $options = get_option('estimador_options');
    echo '<input type="number" step="any" id="estimador_apertura_financiacion_6" name="estimador_options[estimador_apertura_financiacion_6]" value="' . esc_attr($options['estimador_apertura_financiacion_6']) . '">';
}

function estimador_apertura_financiacion_10_callback() {
    $options = get_option('estimador_options');
    echo '<input type="number" step="any" id="estimador_apertura_financiacion_10" name="estimador_options[estimador_apertura_financiacion_10]" value="' . esc_attr($options['estimador_apertura_financiacion_10']) . '">';
}

function estimador_apertura_financiacion_12_callback() {
    $options = get_option('estimador_options');
    echo '<input type="number" step="any" id="estimador_apertura_financiacion_12" name="estimador_options[estimador_apertura_financiacion_12]" value="' . esc_attr($options['estimador_apertura_financiacion_12']) . '">';
}

function estimador_apertura_financiacion_18_callback() {
    $options = get_option('estimador_options');
    echo '<input type="number" step="any" id="estimador_apertura_financiacion_18" name="estimador_options[estimador_apertura_financiacion_18]" value="' . esc_attr($options['estimador_apertura_financiacion_18']) . '">';
}

function estimador_apertura_financiacion_24_callback() {
    $options = get_option('estimador_options');
    echo '<input type="number" step="any" id="estimador_apertura_financiacion_24" name="estimador_options[estimador_apertura_financiacion_24]" value="' . esc_attr($options['estimador_apertura_financiacion_24']) . '">';
}

function estimador_apertura_financiacion_36_callback() {
    $options = get_option('estimador_options');
    echo '<input type="number" step="any" id="estimador_apertura_financiacion_36" name="estimador_options[estimador_apertura_financiacion_36]" value="' . esc_attr($options['estimador_apertura_financiacion_36']) . '">';
}

function estimador_func(){ 

    // Recuperamos las variables puestas en la página de configuración del plugin
    $options = get_option('estimador_options');
    $estimador_webhook_url = $options['estimador_webhook_url'];
    $estimador_correo_admin = $options['estimador_correo_admin'];
    $estimador_precio_paredes_menos50 = $options['estimador_precio_paredes_menos50'];
    $estimador_precio_paredes_entre50_75 = $options['estimador_precio_paredes_entre50_75'];
    $estimador_precio_paredes_entre75_100 = $options['estimador_precio_paredes_entre75_100'];
    $estimador_precio_paredes_entre100_125 = $options['estimador_precio_paredes_entre100_125'];
    $estimador_precio_paredes_entre125_175 = $options['estimador_precio_paredes_entre125_175'];
    $estimador_precio_paredes_mas175 = $options['estimador_precio_paredes_mas175'];
    $estimador_precio_cubierta_entre50_60 = $options['estimador_precio_cubierta_entre50_60'];
    $estimador_precio_cubierta_entre60_70 = $options['estimador_precio_cubierta_entre60_70'];
    $estimador_precio_cubierta_entre70_80 = $options['estimador_precio_cubierta_entre70_80'];
    $estimador_precio_cubierta_entre80_90 = $options['estimador_precio_cubierta_entre80_90'];
    $estimador_precio_cubierta_entre90_100 = $options['estimador_precio_cubierta_entre90_100'];
    $estimador_precio_cubierta_mas100 = $options['estimador_precio_cubierta_mas100'];
    $estimador_apertura_financiacion_3 = $options['estimador_apertura_financiacion_3'];
    $estimador_apertura_financiacion_6 = $options['estimador_apertura_financiacion_6'];
    $estimador_apertura_financiacion_10 = $options['estimador_apertura_financiacion_10'];
    $estimador_apertura_financiacion_12 = $options['estimador_apertura_financiacion_12'];
    $estimador_apertura_financiacion_18 = $options['estimador_apertura_financiacion_18'];
    $estimador_apertura_financiacion_24 = $options['estimador_apertura_financiacion_24'];
    $estimador_apertura_financiacion_36 = $options['estimador_apertura_financiacion_36'];

    wp_enqueue_style('fase1-styles', plugin_dir_url(__FILE__) . 'css/styles.css', array(), false, 'all');
    wp_enqueue_script('fase1-script', plugin_dir_url(__FILE__) . 'js/scripts.js', array('jquery'), '0.1.102', true);
    wp_localize_script('fase1-script', 'estimadorData', array('estimador_webhook_url' => $estimador_webhook_url,
                                                              'estimador_correo_admin' => $estimador_correo_admin,
                                                              'estimador_precio_paredes_menos50' => $estimador_precio_paredes_menos50,
                                                              'estimador_precio_paredes_entre50_75' => $estimador_precio_paredes_entre50_75,
                                                              'estimador_precio_paredes_entre75_100' => $estimador_precio_paredes_entre75_100,
                                                              'estimador_precio_paredes_entre100_125' => $estimador_precio_paredes_entre100_125,
                                                              'estimador_precio_paredes_entre125_175' => $estimador_precio_paredes_entre125_175,
                                                              'estimador_precio_paredes_mas175' => $estimador_precio_paredes_mas175,
                                                              'estimador_precio_cubierta_entre50_60' => $estimador_precio_cubierta_entre50_60,
                                                              'estimador_precio_cubierta_entre60_70' => $estimador_precio_cubierta_entre60_70,
                                                              'estimador_precio_cubierta_entre70_80' => $estimador_precio_cubierta_entre70_80,
                                                              'estimador_precio_cubierta_entre80_90' => $estimador_precio_cubierta_entre80_90,
                                                              'estimador_precio_cubierta_entre90_100' => $estimador_precio_cubierta_entre90_100,
                                                              'estimador_precio_cubierta_mas100' => $estimador_precio_cubierta_mas100,
                                                              'estimador_apertura_financiacion_3' => $estimador_apertura_financiacion_3,
                                                              'estimador_apertura_financiacion_6' => $estimador_apertura_financiacion_6,
                                                              'estimador_apertura_financiacion_10' => $estimador_apertura_financiacion_10,
                                                              'estimador_apertura_financiacion_12' => $estimador_apertura_financiacion_12,
                                                              'estimador_apertura_financiacion_18' => $estimador_apertura_financiacion_18,
                                                              'estimador_apertura_financiacion_24' => $estimador_apertura_financiacion_24,
                                                              'estimador_apertura_financiacion_36' => $estimador_apertura_financiacion_36));
    wp_localize_script('fase1-script', 'ajax_object', array('ajax_url' => admin_url('admin-ajax.php')));
    ob_start();
    ?>
        <div id="estimador">
            <div class="contenedor">
                <h1>
                    Estimación rápida
                </h1>
                <div id="contenedorGeneral">
                    <div id="generalIzquierda">
                        <div id="pared_cubierta">
                            <div>
                                <span>¿Qué quieres aislar?</span>
                                <div id="eleccionParedCubierta_cont" class="toggle-container">
                                    <input type="radio" name="eleccionParedCubierta" id="pared" checked><label for="pared" class="toggle-label selected">Paredes</label>
                                    <input type="radio" name="eleccionParedCubierta" id="cubierta"><label for="cubierta" class="toggle-label">Cubierta</label>
                                </div>
                            </div>
                            <div class="banner_tip">
                                <div>
                                    <span>Si quieres aislar ambas cosas <a href="https://eccoaisla.com/contacto" target="_blank"><span class="negrita">contacta con nosotros</span></a> y <span class="negrita">llévate un descuento</span></span>
                                </div>
                            </div>
                        </div>
                        <div id="toggles_cont">
                            <div id="tipoVivienda_cont">
                                <span>
                                    ¿Qué tipo de vivienda quieres aislar?
                                </span>
                                <div class="input_cont">
                                    <div>
                                        <input type="checkbox" id="viviendaIndependiente" /><label for="viviendaIndependiente"></label>
                                        <span>Vivienda independiente</span>
                                    </div>
                                    <div>
                                        <input type="checkbox" id="viviendaEdificio" /><label for="viviendaEdificio"></label>
                                        <span>Vivienda en un edificio</span>
                                    </div>
                                </div>
                            </div>
                            <div id="columnaDerecha">
                                <div id="tamanoPared_cont">
                                    <span>
                                        Tamaño de la vivienda
                                    </span>
                                    <div class="input_cont">
                                        <div>
                                            <input type="checkbox" id="0_50"><label for="0_50"></label>
                                            <span>Menos de 50 m<sup>2</sup></span>
                                        </div>
                                        <div>
                                            <input type="checkbox" id="100_125"><label for="100_125"></label>
                                            <span>101-125 m<sup>2</sup></span>
                                        </div>
                                        <div>
                                            <input type="checkbox" id="50_75"><label for="50_75"></label>
                                            <span>50-75 m<sup>2</sup></span>
                                        </div>
                                        <div>
                                            <input type="checkbox" id="125_175"><label for="125_175"></label>
                                            <span>125-175 m<sup>2</sup></span>
                                        </div>
                                        <div>
                                            <input type="checkbox" id="75_100"><label for="75_100"></label>
                                            <span>76-100 m<sup>2</sup></span>
                                        </div>
                                        <div>
                                            <input type="checkbox" id="175"><label for="175"></label>
                                            <span>Más de 176 m<sup>2</sup></span>
                                        </div>
                                    </div>
                                </div>
                                <div id="tamanoCubierta_cont">
                                    <span>
                                        Tamaño de cubierta
                                    </span>
                                    <div class="input_cont">
                                        <div>
                                            <input type="checkbox" id="50_60"><label for="50_60"></label>
                                            <span>50-60 m<sup>2</sup></span>
                                        </div> 
                                        <div>
                                            <input type="checkbox" id="80_90"><label for="80_90"></label>
                                            <span>81-90 m<sup>2</sup></span>
                                        </div>
                                        <div>
                                            <input type="checkbox" id="60_70"><label for="60_70"></label>
                                            <span>61-70 m<sup>2</sup></span>
                                        </div>
                                        <div>
                                            <input type="checkbox" id="90_100"><label for="90_100"></label>
                                            <span>91-100 m<sup>2</sup></span>
                                        </div>
                                        <div>
                                            <input type="checkbox" id="70_80"><label for="70_80"></label>
                                            <span>71-80 m<sup>2</sup></span>
                                        </div>
                                        <div>
                                            <input type="checkbox" id="100"><label for="100"></label>
                                            <span>Más de 100 m<sup>2</sup></span>
                                        </div>
                                    </div>
                                </div>
                            </div>  
                        </div>
                    </div>
                    <div id="tuFinanciacion">
                        <div id="totalEstimacion_cont">
                            <div id="precioComision_cont">
                                <div id="precio_cont">
                                    <div id="desde">desde</div>
                                    <div id="totalEstimacion">
                                        <div id="estimacionDinamica">0</div>
                                        <div>€/mes</div>
                                    </div>
                                </div>
                                <div id="comision_cont">
                                    <div id="precioContado_cont">
                                    <div>
                                        <div id="totalEstimacionContado"><span>0</span> €</div>
                                        <div id="totalContado">Coste del aislamiento sin financiar</div>
                                    </div>
                            </div>
                                    <div id="comisionApertura_cont">
                                        <div>Comisión de apertura</div>
                                        <div>
                                            <div id="comision_apertura"><span id="comision_dinamica"></span> %</div>
                                            <div id="comision_apertura_calculada"><span id="comision_calculada_dinamica">0</span> €</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="slider_financiacion_cont">
                                <div id="valorSlider">3</div>
                                <input type="range" min="0" max="6" value="0" step="1" id="sliderRango">
                                <div class="marcas_valores">
                                    <span>3</span><span>6</span><span>10</span><span>12</span><span>18</span><span>24</span><span>36</span>
                                </div>
                            </div>
                            <div id="financiacionCTA_cont">
                                <div>
                                    <button id="financiacionCTA" disabled>Solicitar presupuesto</button>
                                </div>
                            </div>
                            <div id="estaticosFinanciacion">
                                <div>Se cargará un primer recibo por la comisión de apertura en los días siguientes a la formalización del préstamo</div>
                                <div class="negrita">Comisión mínima de apertura: 30 €</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Modal -->
        <div id="modalFinanciacion" class="modal-background">

        <!-- Contenido del modal -->
        <div class="modal-content">
        <span class="close">&times;</span>
        <h3>Solicita tu presupuesto</h3>
        <div id="aclaracionObligatorio">
            <span>(*) campo obligatorio</span>
        </div>
        <!-- Formulario -->
        <div id="formFinanciacion">
            <div id="nombreApellidos_financiacion">
                <div id="nombreFinanciacion_cont">
                    <label for="nombreFinanciacion">Nombre<span class="campoObligatorio">*</span></label>
                    <input type="text" name="nombreFinanciacion" id="nombreFinanciacion">
                    <span class="mensajeValidacion"></span>
                </div>
                <div id="apellidosFinanciacion_cont">
                    <label for="apellidosFinanciacion">Apellidos<span class="campoObligatorio">*</span></label>
                    <input type="text" name="apellidosFinanciacion" id="apellidosFinanciacion">
                    <span class="mensajeValidacion"></span>
                </div>
            </div>
            <div id="correoTelefono_financiacion">
                <div id="correoFinanciacion_cont">
                    <label for="correoFinanciacion">Correo electrónico<span class="campoObligatorio">*</span></label>
                    <input type="email" name="correoFinanciacion" id="correoFinanciacion">
                    <span class="mensajeValidacion"></span>
                </div>
                <div id="telefonoFinanciacion_cont">
                    <label for="telefonoFinanciacion">Teléfono móvil<span class="campoObligatorio">*</span></label>
                    <input type="tel" name="telefonoFinanciacion" id="telefonoFinanciacion">
                    <span class="mensajeValidacion"></span>
                </div>
            </div>
            <div id="municipioProvinciaFinanciacion_cont">
                <div id="municipioFinanciacion_cont">
                    <label for="municipioFinanciacion">Municipio<span class="campoObligatorio">*</span></label>
                    <input type="text" name="municipioFinanciacion" id="municipioFinanciacion">
                    <span class="mensajeValidacion"></span>
                </div>
                <div id="provinciaFinanciacion_cont">
                    <label for="provinciaFinanciacion">Provincia<span class="campoObligatorio">*</span></label>
                    <select name="provinciaFinanciacion" id="provinciaFinanciacion">
                        <option value="">Elige Provincia</option>
                        <option value="Álava/Araba">Álava/Araba</option>
                        <option value="Albacete">Albacete</option>
                        <option value="Alicante">Alicante</option>
                        <option value="Almería">Almería</option>
                        <option value="Asturias">Asturias</option>
                        <option value="Ávila">Ávila</option>
                        <option value="Badajoz">Badajoz</option>
                        <option value="Baleares">Baleares</option>
                        <option value="Barcelona">Barcelona</option>
                        <option value="Burgos">Burgos</option>
                        <option value="Cáceres">Cáceres</option>
                        <option value="Cádiz">Cádiz</option>
                        <option value="Cantabria">Cantabria</option>
                        <option value="Castellón">Castellón</option>
                        <option value="Ceuta">Ceuta</option>
                        <option value="Ciudad Real">Ciudad Real</option>
                        <option value="Córdoba">Córdoba</option>
                        <option value="Cuenca">Cuenca</option>
                        <option value="Gerona/Girona">Gerona/Girona</option>
                        <option value="Granada">Granada</option>
                        <option value="Guadalajara">Guadalajara</option>
                        <option value="Guipúzcoa/Gipuzkoa">Guipúzcoa/Gipuzkoa</option>
                        <option value="Huelva">Huelva</option>
                        <option value="Huesca">Huesca</option>
                        <option value="Jaén">Jaén</option>
                        <option value="La Coruña/A Coruña">La Coruña/A Coruña</option>
                        <option value="La Rioja">La Rioja</option>
                        <option value="Las Palmas">Las Palmas</option>
                        <option value="León">León</option>
                        <option value="Lérida/Lleida">Lérida/Lleida</option>
                        <option value="Lugo">Lugo</option>
                        <option value="Madrid">Madrid</option>
                        <option value="Málaga">Málaga</option>
                        <option value="Melilla">Melilla</option>
                        <option value="Murcia">Murcia</option>
                        <option value="Navarra">Navarra</option>
                        <option value="Orense/Ourense">Orense/Ourense</option>
                        <option value="Palencia">Palencia</option>
                        <option value="Pontevedra">Pontevedra</option>
                        <option value="Salamanca">Salamanca</option>
                        <option value="Segovia">Segovia</option>
                        <option value="Sevilla">Sevilla</option>
                        <option value="Soria">Soria</option>
                        <option value="Tarragona">Tarragona</option>
                        <option value="Tenerife">Tenerife</option>
                        <option value="Teruel">Teruel</option>
                        <option value="Toledo">Toledo</option>
                        <option value="Valencia">Valencia</option>
                        <option value="Valladolid">Valladolid</option>
                        <option value="Vizcaya/Bizkaia">Vizcaya/Bizkaia</option>
                        <option value="Zamora">Zamora</option>
                        <option value="Zaragoza">Zaragoza</option>
                    </select>
                    <span class="mensajeValidacion"></span>
                </div>
            </div>

            <div id="politicaSubmitFinanciacion_cont">
                <div id="politicaFinanciacion_cont">
                    <input type="checkbox" name="politicaFinanciacion" id="politicaFinanciacion">
                    <label for="politicaFinanciacion">Acepto la <a href="https://eccoaisla.com/politica-de-privacidad-de-datos/" target="_blank">política de privacidad</a> referente al uso de mis datos personales<span class="campoObligatorio">*</span></label>
                    <div>
                        <span class="mensajeValidacion"></span>
                    </div>
                </div>
                <div id="submitFinanciacion_cont">
                    <button id="submitFinanciacion">Solicitar</button>
                </div>
            </div>
        </div>
    <?php
    return ob_get_clean();
}

add_shortcode('fase1', 'estimador_func');

function enviar_email() {
    $correo_admin_email = $_POST['correo_admin'];
    $nombre_usuario_email = $_POST['nombre_usuario'];
    $apellidos_usuario_email = $_POST['apellidos_usuario'];
    $correo_usuario_email = $_POST['correo_usuario'];
    $telefono_usuario_email = $_POST['telefono_usuario'];
    $municipio_usuario_email = $_POST['municipio_usuario'];
    $provincia_usuario_email = $_POST['provincia_usuario'];
    $paredes_cubierta_email = $_POST['paredes_cubierta'];
    $tipo_vivienda_email = $_POST['tipo_vivienda'];
    $tamano_vivienda_email = $_POST['tamano_vivienda'];
    $precio_financiado_email = $_POST['precio_financiado'];
    $precio_sinFinanciar_email = $_POST['precio_sinFinanciar'];
    $comision_apertura_email = $_POST['comision_apertura'];
    $cuantia_apertura_email = $_POST['cuantia_apertura'];
    $meses_financiacion_email = $_POST['meses_financiacion'];

    $to = $correo_admin_email;
    $subject = 'Nueva estimación de Fase 1 | Eccoaisla';

    $message = "<html>
                    <h1>Nueva estimación de Fase 1</h1>
                    <h3><span style='font-weight:bold;'>$nombre_usuario_email $apellidos_usuario_email</span> ha hecho una estimación de Fase 1 y ha enviado sus datos para que nos pongamos en contacto con él</h3>
                    <br>
                    <h3>Datos personales del interesado</h3>
                    <table style='border-collapse: collapse; text-align: left; width: 100%;'>
                        <tr>
                            <th style='border: 1px solid #000000; padding: 1em; width: 50%;'>Nombre</th>
                            <td style='border: 1px solid #000000; padding: 1em; width: 50%;'>$nombre_usuario_email</td>
                        </tr>
                        <tr>
                            <th style='border: 1px solid #000000; padding: 1em; width: 50%;'>Apellidos</th>
                            <td style='border: 1px solid #000000; padding: 1em; width: 50%;'>$apellidos_usuario_email</td>
                        </tr>
                        <tr>
                            <th style='border: 1px solid #000000; padding: 1em; width: 50%;'>Correo electrónico</th>
                            <td style='border: 1px solid #000000; padding: 1em; width: 50%;'>$correo_usuario_email</td>
                        </tr>
                        <tr>
                            <th style='border: 1px solid #000000; padding: 1em; width: 50%;'>Teléfono</th>
                            <td style='border: 1px solid #000000; padding: 1em; width: 50%;'>$telefono_usuario_email</td>
                        </tr>
                        <tr>
                            <th style='border: 1px solid #000000; padding: 1em; width: 50%;'>Municipio</th>
                            <td style='border: 1px solid #000000; padding: 1em; width: 50%;'>$municipio_usuario_email</td>
                        </tr>
                        <tr>
                            <th style='border: 1px solid #000000; padding: 1em; width: 50%;'>Provincia</th>
                            <td style='border: 1px solid #000000; padding: 1em; width: 50%;'>$provincia_usuario_email</td>
                        </tr>
                        <tr>
                            <th style='border: 1px solid #000000; padding: 1em; width: 50%;'>Provincia</th>
                            <td style='border: 1px solid #000000; padding: 1em; width: 50%;'>$provincia_usuario_email</td>
                        </tr>
                    </table>
                    <br><br>
                    <h3>Datos de la estimación</h3>
                    <table style='border-collapse: collapse; text-align: left; width: 100%;'>
                        <tr>
                            <th style='border: 1px solid #000000; padding: 1em; width: 50%;'>¿Aisla paredes o cubierta?</th>
                            <td style='border: 1px solid #000000; padding: 1em; width: 50%;'>$paredes_cubierta_email</td>
                        </tr>
                        <tr>
                            <th style='border: 1px solid #000000; padding: 1em; width: 50%;'>Tipo de vivienda</th>
                            <td style='border: 1px solid #000000; padding: 1em; width: 50%;'>$tipo_vivienda_email</td>
                        </tr>
                        <tr>
                            <th style='border: 1px solid #000000; padding: 1em; width: 50%;'>Tamaño de vivienda</th>
                            <td style='border: 1px solid #000000; padding: 1em; width: 50%;'>$tamano_vivienda_email</td>
                        </tr>
                        <tr>
                            <th style='border: 1px solid #000000; padding: 1em; width: 50%;'>Precio financiado</th>
                            <td style='border: 1px solid #000000; padding: 1em; width: 50%;'>$precio_financiado_email</td>
                        </tr>
                        <tr>
                            <th style='border: 1px solid #000000; padding: 1em; width: 50%;'>Precio sin financiar</th>
                            <td style='border: 1px solid #000000; padding: 1em; width: 50%;'>$precio_sinFinanciar_email</td>
                        </tr>
                        <tr>
                            <th style='border: 1px solid #000000; padding: 1em; width: 50%;'>Porcentaje de comisión de apertura</th>
                            <td style='border: 1px solid #000000; padding: 1em; width: 50%;'>$comision_apertura_email</td>
                        </tr>
                        <tr>
                            <th style='border: 1px solid #000000; padding: 1em; width: 50%;'>Meses de financiación</th>
                            <td style='border: 1px solid #000000; padding: 1em; width: 50%;'>$meses_financiacion_email</td>
                        </tr>
                        <tr>
                            <th style='border: 1px solid #000000; padding: 1em; width: 50%;'>Cuantía de apertura</th>
                            <td style='border: 1px solid #000000; padding: 1em; width: 50%;'>$cuantia_apertura_email</td>
                        </tr>
                    </table>                        
                </body>
            </html>";
    
    $headers = array('Content-Type: text/html; charset=UTF-8');

    if(wp_mail($to, $subject, $message, $headers)) {
        wp_send_json_success();
    } else {
        wp_send_json_error();
    }

    wp_die();
}
add_action('wp_ajax_enviar_email', 'enviar_email');
add_action('wp_ajax_nopriv_enviar_email', 'enviar_email');

?>