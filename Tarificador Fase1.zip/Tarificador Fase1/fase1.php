<?php
/*
Plugin Name: Estimación rápida
Plugin URI: https://webcafeina.com
Description: Estimador rápido de precio para aislamiento
Version: 0.1.24
Author: Webcafeina
Author URI: https://webcafeina.com
License: GPL2
*/

function estimador_func(){ 
    wp_enqueue_style('fase1-styles', plugin_dir_url(__FILE__) . 'css/styles.css', array(), false, 'all');
    wp_enqueue_script('fase1-script', plugin_dir_url(__FILE__) . 'js/scripts.js', array('jquery'), '0.1.1', true);
    ob_start();
    ?>
        <div id="estimador">
            <div class="contenedor">
                <h1>
                    Estimación rápida
                </h1>
                <div id="toggles_cont">

                    <div id="tipoVivienda_cont">
                        <h3>
                            Tipo de vivienda
                        </h3>
                        <div class="input_cont">
                            <div>
                                <input type="checkbox" id="viviendaIndependiente" /><label for="viviendaIndependiente"></label>
                                <span>Vivienda independiente</span>
                            </div>
                            <div>
                                <input type="checkbox" id="viviendaEdificio" /><label for="viviendaEdificio"></label>
                                <span>Vivienda en un edificio</span>
                            </div>
                        </div>
                    </div>

                    <div id="columnaDerecha">
                        <div id="tamanoPared_cont">
                            <h3>
                                Tamaño de pared
                            </h3>
                            <div class="input_cont">
                                <div>
                                    <input type="checkbox" id="0_50" /><label for="0_50"></label>
                                    <span>Entre 0 y 50 m<sup>2</sup></span>
                                </div>
                                <div>
                                    <input type="checkbox" id="50_75" /><label for="50_75"></label>
                                    <span>Entre 50 y 75 m<sup>2</sup></span>
                                </div>
                                <div>
                                    <input type="checkbox" id="75_100" /><label for="75_100"></label>
                                    <span>Entre 75 y 100 m<sup>2</sup></span>
                                </div>
                                <div>
                                    <input type="checkbox" id="100_125" /><label for="100_125"></label>
                                    <span>Entre 100 y 125 m<sup>2</sup></span>
                                </div>
                                <div>
                                    <input type="checkbox" id="125_175" /><label for="125_175"></label>
                                    <span>Entre 125 y 175 m<sup>2</sup></span>
                                </div>
                                <div>
                                    <input type="checkbox" id="175" /><label for="175"></label>
                                    <span>Mas de 175 m<sup>2</sup></span>
                                </div>
                            </div>
                        </div>

                        <div id="tamanoCubierta_cont">
                            <h3>
                                Tamaño de cubierta
                            </h3>
                            <div class="input_cont">
                                <div>
                                    <input type="checkbox" id="50_60" /><label for="50_60"></label>
                                    <span>Entre 50 y 60 m<sup>2</sup></span>
                                </div>
                                <div>
                                    <input type="checkbox" id="60_70" /><label for="60_70"></label>
                                    <span>Entre 60 y 70 m<sup>2</sup></span>
                                </div>
                                <div>
                                    <input type="checkbox" id="70_80" /><label for="70_80"></label>
                                    <span>Entre 70 y 80 m<sup>2</sup></span>
                                </div>
                                <div>
                                    <input type="checkbox" id="80_90" /><label for="80_90"></label>
                                    <span>Entre 80 y 90 m<sup>2</sup></span>
                                </div>
                                <div>
                                    <input type="checkbox" id="90_100" /><label for="90_100"></label>
                                    <span>Entre 90 y 100 m<sup>2</sup></span>
                                </div>
                                <div>
                                    <input type="checkbox" id="100" /><label for="100"></label>
                                    <span>Mas de 100 m<sup>2</sup></span>
                                </div>
                            </div>
                        </div>

                        <div id="pared_cubierta">
                            <div>
                                <span>¿Actuar sobre pared o sobre cubierta?</span>
                                <div id="eleccionParedCubierta_cont">
                                    <input type="radio" name="eleccionParedCubierta" id="pared"><label for="pared">Pared</label>
                                    <input type="radio" name="eleccionParedCubierta" id="cubierta"><label for="cubierta">Cubierta</label>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

                <div id="tuFinanciacion">
                    <div id="totalEstimacion_cont">
                        <span id="totalEstimacion">200</span>
                        <span id="alMes"> al mes</span>
                    </div>
                </div>

            </div>
        </div>
    <?php
    return ob_get_clean();
}

add_shortcode('fase1', 'estimador_func');
?>