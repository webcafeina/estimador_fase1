<?php
/*
Plugin Name: Estimación rápida
Plugin URI: https://webcafeina.com
Description: Estimador rápido de precio para aislamiento
Version: 0.1.4
Author: Webcafeina
Author URI: https://webcafeina.com
License: GPL2
*/

function estimador_func(){ 
    wp_enqueue_style('fase1-styles', plugin_dir_url(__FILE__) . 'css/styles.css', array(), false, 'all');
    wp_enqueue_script('fase1-script', plugin_dir_url(__FILE__) . 'js/scripts.js', array('jquery'), '0.1.1', true);
    ob_start();
    ?>
        <div id="estimador">
            <div class="contenedor">
                <h1>
                    Estimación rápida
                </h1>
                <div id="tipoVivienda_cont">
                    <h2>
                        Tipo de vivienda
                    </h2>
                    <div>
                        <input type="radio" name="tipoVivienda" id="viviendaIndependiente">
                        <label for="viviendaIndependiente">Vivienda Independiente</label>
                    </div>
                    <div>
                        <input type="radio" name="tipoVivienda" id="ultimaPlanta">
                        <label for="ultimaPlanta"> Ultima planta de un edificio</label>
                    </div>
                    <div>
                        <input type="radio" name="tipoVivienda" id="viviendaEdificio">
                        <label for="viviendaEdificio">Vivienda en un edificio</label>
                    </div>
                    <div>
                        <input type="radio" name="tipoVivienda" id="localComercial">
                        <label for="localComercial">Local comercial</label>
                    </div>
                    <div>
                        <input type="radio" name="tipoVivienda" id="garaje">
                        <label for="garaje">Garaje</label>
                    </div>
                    <div>
                        <input type="radio" name="tipoVivienda" id="naveIndustrial">
                        <label for="naveIndustrial">Nave industrial</label>
                    </div>

                </div>

                <div id="tamanoVivienda_cont">
                    <h2>
                        Tamaño de vivienda
                    </h2>
                    <div>
                        <input type="radio" name="tamanoVivienda" id="120m">
                        <label for="120m">Hasta 120m<sup>2</sup></label>
                    </div>
                    <div>
                        <input type="radio" name="tamanoVivienda" id="150m">
                        <label for="150m">Hasta 150m<sup>2</sup></label>
                    </div>
                    <div>
                        <input type="radio" name="tamanoVivienda" id="180m">
                        <label for="180m">Hasta 180m<sup>2</sup></label>
                    </div>
                </div>

                <div id="aislamientoTejado_cont">
                    <div>
                        <input type="checkbox" name="aislamientoTejado" id="tejado">
                        <label for="tejado">Añadir aislamiento térmico en tejado o cubierta</label>
                    </div>
                </div>

                <div id="tuFinanciacion">
                    <div id="totalEstimacion_cont">
                        <span id="totalEstimacion">200</span>
                        <span id="alMes"> al mes</span>
                    </div>
                </div>

            </div>
        </div>
    <?php
    return ob_get_clean();
}

add_shortcode('fase1', 'estimador_func');
?>