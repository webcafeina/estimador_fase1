<?php
/*
Plugin Name: Estimación rápida
Plugin URI: https://webcafeina.com
Description: Estimador rápido de precio para aislamiento
Version: 0.1.2
Author: Webcafeina
Author URI: https://webcafeina.com
License: GPL2
*/

function estimador_func(){ 
    ?>
        <div id="estimador">
            <div class="contenedor">
                <h1>
                    Estimación rápida
                </h1>
                <div id="tipoVivienda_cont">
                    <h2>
                        Tipo de vivienda
                    </h2>
                    <div>
                        <label for="viviendaIndependiente">Vivienda Independiente</label>
                        <input type="radio" name="tipoVivienda" id="viviendaIndependiente">
                    </div>
                    <div>
                        <label for="ultimaPlanta"> Ultima planta de un edificio</label>
                        <input type="radio" name="tipoVivienda" id="ultimaPlanta">
                    </div>
                    <div>
                        <label for="viviendaEdificio">Vivienda en un edificio</label>
                        <input type="radio" name="tipoVivienda" id="viviendaEdificio">
                    </div>
                    <div>
                        <label for="localComercial">Local comercial</label>
                        <input type="radio" name="tipoVivienda" id="localComercial">
                    </div>
                    <div>
                        <label for="garaje">Garaje</label>
                        <input type="radio" name="tipoVivienda" id="garaje">
                    </div>
                    <div>
                        <label for="naveIndustrial">Nave industrial</label>
                        <input type="radio" name="tipoVivienda" id="naveIndustrial">
                    </div>

                </div>

                <div id="tamanoVivienda_cont">
                    <h2>
                        Tamaño de vivienda
                    </h2>
                    <div>
                        <label for="120m">Hasta 120m<sup>2</sup></label>
                        <input type="radio" name="tamanoVivienda" id="120m">
                    </div>
                    <div>
                        <label for="150m">Hasta 150m<sup>2</sup></label>
                        <input type="radio" name="tamanoVivienda" id="150m">
                    </div>
                    <div>
                        <label for="180m">Hasta 180m<sup>2</sup></label>
                        <input type="radio" name="tamanoVivienda" id="180m">
                    </div>
                </div>

                <div id="aislamientoTejado_cont">
                    <div>
                        <label for="tejado">Añadir aislamiento térmico en tejado o cubierta</label>
                        <input type="checkbox" name="aislamientoTejado" id="tejado">
                    </div>
                </div>

                <div id="tuFinanciacion">
                    <div id="totalEstimacion_cont">
                        <span id="totalEstimacion">200</span>
                        <span id="alMes"> al mes</span>
                    </div>
                </div>

            </div>
        </div>
    <?php
}

add_shortcode('fase1', 'estimador_func');
?>